package tech.crud.emplyoeemanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmplyoeeManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmplyoeeManagerApplication.class, args);
	}

}
