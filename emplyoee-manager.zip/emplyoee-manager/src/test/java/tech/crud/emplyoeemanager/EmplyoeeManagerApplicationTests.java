package tech.crud.emplyoeemanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmplyoeeManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
